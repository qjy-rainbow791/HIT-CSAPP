#include <stdio.h>

int main()
{
    printf("Hello 120L022314-�ľ�Ң");
    return 0;
}